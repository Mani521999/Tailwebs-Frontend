export const ROLES = {
  TEACHER: 'teacher',
  STUDENT: 'student',
};

export const STATUS = {
  DRAFT: 'Draft',
  PUBLISHED: 'Published',
  COMPLETED: 'Completed',
};
